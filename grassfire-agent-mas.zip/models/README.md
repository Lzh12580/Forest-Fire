# 模型权重目录

本目录用于存放预训练模型权重文件。由于文件体积较大，不纳入 Git 版本控制。

## 需要下载的模型

| 模型 | 文件名 | 大小 | 下载地址 |
|------|--------|------|---------|
| 轻量化 YOLOv8-n | `yolov8n_grassfire.pt` | ~6MB | [Release v1.0](https://github.com/yourname/GrassFire-Agent-MAS/releases) |
| RL 策略网络 | `rl_policy_net.pth` | ~12MB | [Release v1.0](https://github.com/yourname/GrassFire-Agent-MAS/releases) |

## 放置方式

将下载的 `.pt` 和 `.pth` 文件直接放入本目录：

```
models/
├── yolov8n_grassfire.pt
├── rl_policy_net.pth
└── README.md
```

## 自行训练

如需自行训练：

- **YOLOv8-n**：使用 `ultralytics` 库，在草原火数据集上微调
- **RL 策略网络**：使用 Stable-Baselines3 或自定义 PPO 实现
