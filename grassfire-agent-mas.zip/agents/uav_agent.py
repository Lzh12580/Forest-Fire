"""
UAV Agent: 空基无人机 Agent
负责低空精准烟羽与火点识别（基于轻量化 YOLO）
"""
import random
import time
from typing import Dict, Any, List
from .base_agent import BaseAgent


class UAVAgent(BaseAgent):
    def __init__(self, config: Dict[str, Any]):
        super().__init__("UAVAgent", config)
        self.model_path = config.get("model_path", "models/yolov8n.pt")
        self.input_size = config.get("input_size", [640, 640])
        self.conf_threshold = config.get("confidence_threshold", 0.70)
        self.fp16 = config.get("fp16", True)
        self.device = config.get("device", "cpu")
        self.patrol_altitude = config.get("patrol_altitude", 120)

    def _mock_yolo_inference(self, image_id: str) -> List[Dict]:
        """模拟 YOLOv8-n 推理结果"""
        detections = []
        # 模拟检测到烟雾
        if random.random() > 0.3:
            detections.append({
                "class": "smoke",
                "bbox": [random.randint(200, 400), random.randint(150, 300),
                         random.randint(420, 600), random.randint(300, 450)],
                "confidence": round(random.uniform(0.72, 0.96), 2)
            })
        # 模拟检测到火点
        if random.random() > 0.4:
            detections.append({
                "class": "fire",
                "bbox": [random.randint(300, 500), random.randint(200, 350),
                         random.randint(480, 620), random.randint(320, 480)],
                "confidence": round(random.uniform(0.78, 0.98), 2)
            })
        return detections

    def perceive(self) -> Dict[str, Any]:
        """模拟无人机航拍图像采集"""
        # 实际场景中此处会接入无人机图传
        image_id = f"uav_img_{int(time.time())}"
        return {
            "image_id": image_id,
            "altitude": self.patrol_altitude,
            "resolution": f"{self.input_size[0]}x{self.input_size[1]}",
            "timestamp": time.time()
        }

    def process(self, data: Dict[str, Any]) -> Dict[str, Any]:
        """执行 YOLO 检测并过滤"""
        image_id = data.get("image_id")
        detections = self._mock_yolo_inference(image_id)

        # 过滤低置信度
        valid_detections = [
            d for d in detections 
            if d["confidence"] >= self.conf_threshold
        ]

        smoke_count = sum(1 for d in valid_detections if d["class"] == "smoke")
        fire_count = sum(1 for d in valid_detections if d["class"] == "fire")

        return {
            "detections": valid_detections,
            "smoke_count": smoke_count,
            "fire_count": fire_count,
            "image_id": image_id,
            "inference_time_ms": round(random.uniform(8, 16), 1),
            "device": self.device,
            "fp16": self.fp16
        }
