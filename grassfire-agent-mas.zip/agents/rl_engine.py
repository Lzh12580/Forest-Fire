"""
RL Decision Engine: 强化学习决策引擎
基于多源融合结果进行动态资源调度与路径规划
"""
import random
import time
from typing import Dict, Any, List


class RLDecisionEngine:
    def __init__(self, config: Dict[str, Any]):
        self.name = "RLDecisionEngine"
        self.enabled = config.get("enabled", True)
        self.model_path = config.get("model_path", "models/rl_policy_net.pth")
        self.action_space = config.get("action_space", {})
        self.reward_weights = config.get("reward_weights", {})

    def _calculate_consensus(self, reports: List[Dict]) -> Dict[str, Any]:
        """多 Agent 共识机制：综合各 Agent 置信度"""
        confidences = []
        fire_indicators = 0

        for report in reports:
            agent = report.get("agent", "")
            data = report.get("data", {})

            if agent == "SatelliteAgent":
                confidences.append(data.get("high_confidence_count", 0) * 0.15)
                fire_indicators += data.get("high_confidence_count", 0)
            elif agent == "UAVAgent":
                confidences.append(data.get("fire_count", 0) * 0.35)
                fire_indicators += data.get("fire_count", 0)
            elif agent == "GroundAgent":
                confidences.append(data.get("anomaly_count", 0) * 0.25)
                fire_indicators += data.get("anomaly_count", 0)

        overall_confidence = min(sum(confidences) / max(len(confidences), 1), 1.0)
        return {
            "overall_confidence": round(overall_confidence, 3),
            "fire_indicators": fire_indicators,
            "consensus_reached": overall_confidence > 0.7 and fire_indicators >= 2
        }

    def predict_spread(self, consensus: Dict, cfd_params: Dict) -> Dict[str, Any]:
        """火势蔓延预测"""
        wind_speed = cfd_params.get("wind_speed", 5.0)
        base_spread = random.uniform(0.5, 3.0)
        spread_rate = base_spread * (1 + wind_speed / 10)

        return {
            "spread_rate_km2_h": round(spread_rate, 2),
            "estimated_impact_2h": round(spread_rate * 2, 2),
            "risk_level": "high" if spread_rate > 2.5 else "medium" if spread_rate > 1.5 else "low",
            "wind_factor": wind_speed
        }

    def plan_dispatch(self, consensus: Dict, spread: Dict) -> Dict[str, Any]:
        """生成最优资源调度方案"""
        max_uav = self.action_space.get("max_uav", 5)
        max_patrol = self.action_space.get("max_ground_patrol", 3)

        risk = spread.get("risk_level", "low")
        if risk == "high":
            uav_count = max_uav
            patrol_count = max_patrol
        elif risk == "medium":
            uav_count = max(2, max_uav // 2)
            patrol_count = max(1, max_patrol // 2)
        else:
            uav_count = 1
            patrol_count = 1

        # 模拟路径规划
        routes = []
        for i in range(uav_count):
            routes.append({
                "uav_id": f"uav_{i+1}",
                "waypoints": [
                    {"lat": round(random.uniform(41.5, 42.5), 4), "lon": round(random.uniform(112, 113), 4)},
                    {"lat": round(random.uniform(41.5, 42.5), 4), "lon": round(random.uniform(112, 113), 4)}
                ],
                "estimated_time_min": random.randint(10, 30)
            })

        return {
            "dispatch_plan": {
                "uav_count": uav_count,
                "ground_patrol_count": patrol_count,
                "uav_routes": routes,
                "priority": risk
            },
            "resource_cost_score": round((uav_count * 0.2 + patrol_count * 0.15), 2)
        }

    def decide(self, reports: List[Dict], gan_result: Dict) -> Dict[str, Any]:
        """主决策入口"""
        if not self.enabled:
            return {"status": "disabled"}

        consensus = self._calculate_consensus(reports)
        cfd_params = gan_result.get("plume_simulation", {})
        spread = self.predict_spread(consensus, cfd_params)
        dispatch = self.plan_dispatch(consensus, spread)

        # 计算综合 reward
        acc_weight = self.reward_weights.get("detection_accuracy", 1.0)
        time_weight = self.reward_weights.get("response_time", -0.5)
        cost_weight = self.reward_weights.get("resource_cost", -0.3)

        reward = (
            consensus["overall_confidence"] * acc_weight +
            20 * time_weight +  # 假设响应时间 20s
            dispatch["resource_cost_score"] * cost_weight
        )

        return {
            "consensus": consensus,
            "spread_prediction": spread,
            "dispatch_plan": dispatch["dispatch_plan"],
            "reward": round(reward, 3),
            "decision_timestamp": time.time(),
            "final_verdict": "REAL_FIRE" if consensus["consensus_reached"] else "FALSE_ALARM"
        }
