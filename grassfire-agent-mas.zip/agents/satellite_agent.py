"""
Satellite Agent: 天基卫星 Agent
负责广域热异常扫描与粗定位
"""
import random
import time
from typing import Dict, Any
from .base_agent import BaseAgent


class SatelliteAgent(BaseAgent):
    def __init__(self, config: Dict[str, Any]):
        super().__init__("SatelliteAgent", config)
        self.region = config.get("region", {})
        self.threshold = config.get("confidence_threshold", 0.65)
        self.scan_interval = config.get("scan_interval", 300)
        self.last_scan = 0

    def perceive(self) -> Dict[str, Any]:
        """模拟接入 MODIS 卫星热异常数据"""
        current_time = time.time()
        if current_time - self.last_scan < self.scan_interval:
            return {"thermal_anomalies": [], "message": "Scan interval not reached"}

        self.last_scan = current_time
        # 模拟检测到 0-3 个热异常点
        anomaly_count = random.randint(0, 3)
        anomalies = []

        for i in range(anomaly_count):
            lat = random.uniform(
                self.region.get("lat_min", 41.0),
                self.region.get("lat_max", 44.0)
            )
            lon = random.uniform(
                self.region.get("lon_min", 111.0),
                self.region.get("lon_max", 115.0)
            )
            confidence = round(random.uniform(0.45, 0.92), 2)
            anomalies.append({
                "id": f"thermal_{i}",
                "lat": round(lat, 4),
                "lon": round(lon, 4),
                "brightness_temp": round(random.uniform(320, 380), 1),
                "confidence": confidence,
                "flagged": confidence >= self.threshold
            })

        return {
            "thermal_anomalies": anomalies,
            "scan_coverage": f"{self.region.get('lat_min')}N-{self.region.get('lat_max')}N",
            "timestamp": current_time
        }

    def process(self, data: Dict[str, Any]) -> Dict[str, Any]:
        """过滤低置信度异常点，生成初步火点候选"""
        anomalies = data.get("thermal_anomalies", [])
        candidates = [a for a in anomalies if a.get("flagged", False)]

        return {
            "candidates": candidates,
            "total_scanned": len(anomalies),
            "high_confidence_count": len(candidates),
            "requires_uav_verification": len(candidates) > 0
        }
