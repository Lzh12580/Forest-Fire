"""
Coordinator Agent: 协调 Agent
负责多源数据时空对齐、置信度融合、触发长链推理
"""
import time
from typing import Dict, Any, List
from .base_agent import BaseAgent
from .satellite_agent import SatelliteAgent
from .uav_agent import UAVAgent
from .ground_agent import GroundAgent
from .gan_module import PhysicsGAN
from .rl_engine import RLDecisionEngine


class CoordinatorAgent(BaseAgent):
    def __init__(self, config: Dict[str, Any]):
        super().__init__("CoordinatorAgent", config)
        self.interval = config.get("coordinator_interval", 5)

        # 初始化子 Agent
        self.satellite = SatelliteAgent(config.get("satellite", {}))
        self.uav = UAVAgent(config.get("uav", {}))
        self.ground = GroundAgent(config.get("ground", {}))
        self.gan = PhysicsGAN(config.get("gan", {}))
        self.rl = RLDecisionEngine(config.get("rl", {}))

        self.agents = [self.satellite, self.uav, self.ground]

    def perceive(self) -> Dict[str, Any]:
        """协调器本身不直接感知，而是收集各 Agent 上报"""
        return {"status": "coordinating"}

    def process(self, data: Dict[str, Any]) -> Dict[str, Any]:
        """触发各 Agent 运行并融合结果"""
        # Step 1: 并行收集各 Agent 数据
        reports = []
        for agent in self.agents:
            report = agent.run_cycle()
            reports.append(report)

        # Step 2: 判断是否需要深度推理
        needs_deep_reasoning = any(
            r.get("data", {}).get("requires_uav_verification", False) or
            r.get("data", {}).get("requires_attention", False)
            for r in reports
        )

        gan_result = {"plume_simulation": {}}
        rl_result = {}

        if needs_deep_reasoning:
            # Step 3: 物理 GAN 增强
            gan_result = self.gan.augment_samples([])

            # Step 4: RL 共识决策
            rl_result = self.rl.decide(reports, gan_result)

        return {
            "reports": reports,
            "needs_deep_reasoning": needs_deep_reasoning,
            "gan_result": gan_result,
            "rl_result": rl_result,
            "fusion_timestamp": time.time()
        }

    def run(self, max_cycles: int = 1) -> Dict[str, Any]:
        """运行指定轮数的协调循环"""
        results = []
        for i in range(max_cycles):
            cycle_result = self.run_cycle()
            results.append(cycle_result)

            # 打印本轮摘要
            data = cycle_result.get("data", {})
            rl = data.get("rl_result", {})
            if rl:
                verdict = rl.get("final_verdict", "UNKNOWN")
                conf = rl.get("consensus", {}).get("overall_confidence", 0)
                print(f"[Cycle {i+1}] Verdict: {verdict} | Confidence: {conf:.3f}")
            else:
                print(f"[Cycle {i+1}] No anomalies detected. Standby.")

            if i < max_cycles - 1:
                time.sleep(self.interval)

        return {
            "total_cycles": max_cycles,
            "cycles": results,
            "system_status": "operational"
        }
