"""
Ground Agent: 地基传感网 Agent
负责边缘节点温湿度、烟雾、CO 等近地表数据采集
"""
import random
import time
from typing import Dict, Any, List
from .base_agent import BaseAgent


class GroundAgent(BaseAgent):
    def __init__(self, config: Dict[str, Any]):
        super().__init__("GroundAgent", config)
        self.nodes = config.get("edge_nodes", [])
        self.thresholds = config.get("anomaly_threshold", {})
        self.poll_interval = config.get("poll_interval", 10)

    def _read_sensor(self, node: Dict, sensor_type: str) -> float:
        """模拟传感器读数"""
        if sensor_type == "temperature":
            return round(random.uniform(22, 52), 1)
        elif sensor_type == "humidity":
            return round(random.uniform(30, 80), 1)
        elif sensor_type == "smoke":
            return round(random.uniform(0, 100), 1)
        elif sensor_type == "co":
            return round(random.uniform(0, 20), 1)
        elif sensor_type == "pm25":
            return round(random.uniform(10, 120), 1)
        return 0.0

    def perceive(self) -> Dict[str, Any]:
        """轮询所有边缘节点传感器"""
        node_data = []
        for node in self.nodes:
            sensors = {}
            for sensor_type in node.get("sensors", []):
                sensors[sensor_type] = self._read_sensor(node, sensor_type)
            node_data.append({
                "node_id": f"{node['ip']}:{node['port']}",
                "sensors": sensors,
                "online": True,
                "timestamp": time.time()
            })

        return {
            "node_count": len(self.nodes),
            "online_nodes": len([n for n in node_data if n["online"]]),
            "readings": node_data
        }

    def process(self, data: Dict[str, Any]) -> Dict[str, Any]:
        """判断各节点是否异常"""
        anomalies = []
        for node in data.get("readings", []):
            sensors = node.get("sensors", {})
            alerts = []

            for sensor_type, value in sensors.items():
                threshold = self.thresholds.get(sensor_type)
                if threshold and value > threshold:
                    alerts.append({
                        "type": sensor_type,
                        "value": value,
                        "threshold": threshold,
                        "severity": "high" if value > threshold * 1.5 else "medium"
                    })

            if alerts:
                anomalies.append({
                    "node_id": node["node_id"],
                    "alerts": alerts,
                    "overall_risk": max(a["severity"] for a in alerts)
                })

        return {
            "anomalies": anomalies,
            "anomaly_count": len(anomalies),
            "total_nodes": data.get("node_count", 0),
            "requires_attention": len(anomalies) > 0
        }
