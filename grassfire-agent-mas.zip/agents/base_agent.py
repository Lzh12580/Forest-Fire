"""
Base Agent for GrassFire-Agent-MAS
所有 Agent 的抽象基类
"""
from abc import ABC, abstractmethod
from typing import Dict, Any
import time


class BaseAgent(ABC):
    def __init__(self, name: str, config: Dict[str, Any]):
        self.name = name
        self.config = config
        self.enabled = config.get("enabled", True)
        self.status = "idle"

    @abstractmethod
    def perceive(self) -> Dict[str, Any]:
        """感知层：从环境获取原始数据"""
        pass

    @abstractmethod
    def process(self, data: Dict[str, Any]) -> Dict[str, Any]:
        """处理层：对数据进行初步分析"""
        pass

    def report(self, result: Dict[str, Any]) -> Dict[str, Any]:
        """向协调器上报结果"""
        return {
            "agent": self.name,
            "timestamp": time.time(),
            "status": self.status,
            "data": result
        }

    def run_cycle(self) -> Dict[str, Any]:
        """执行一个完整的感知-处理-上报周期"""
        if not self.enabled:
            return {"agent": self.name, "status": "disabled"}

        self.status = "perceiving"
        raw_data = self.perceive()

        self.status = "processing"
        processed = self.process(raw_data)

        self.status = "idle"
        return self.report(processed)
